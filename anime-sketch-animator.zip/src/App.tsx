/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Download, RefreshCw, Trash2, Image as ImageIcon, Sparkles, UploadCloud, Loader2 } from 'lucide-react';
import gsap from 'gsap';

// Helper function to draw a realistic pencil tip
function drawPencil(ctx: CanvasRenderingContext2D, x: number, y: number, canvasWidth: number) {
   ctx.save();
   ctx.translate(x, y);
   
   const scale = Math.max(1, canvasWidth / 800); 
   ctx.scale(scale, scale);
   
   ctx.rotate(-0.3); // slight tilt
   
   ctx.shadowColor = 'rgba(0,0,0,0.4)';
   ctx.shadowBlur = 12;
   ctx.shadowOffsetX = 8;
   ctx.shadowOffsetY = 8;
   
   // Wood tip
   ctx.beginPath();
   ctx.moveTo(0, 0);
   ctx.lineTo(-6, -20);
   ctx.lineTo(6, -20);
   ctx.closePath();
   ctx.fillStyle = '#e5c07b';
   ctx.fill();
   
   // Graphite tip
   ctx.beginPath();
   ctx.moveTo(0, 0);
   ctx.lineTo(-2.5, -8);
   ctx.lineTo(2.5, -8);
   ctx.closePath();
   ctx.fillStyle = '#3f3f46';
   ctx.fill();
   
   // Yellow Body
   ctx.fillStyle = '#fbbf24';
   ctx.fillRect(-6, -100, 12, 80);
   
   // Metal binder
   ctx.fillStyle = '#9ca3af';
   ctx.fillRect(-6, -115, 12, 15);
   
   // Eraser
   ctx.fillStyle = '#fca5a5';
   if (ctx.roundRect) {
     ctx.beginPath();
     ctx.roundRect(-6, -130, 12, 15, [4, 4, 0, 0]);
     ctx.fill();
   } else {
     ctx.fillRect(-6, -130, 12, 15);
   }
   
   ctx.restore();
}

type PresetType = 'light_ink' | 'classic_graphite' | 'dark_charcoal';

const PRESETS: Record<PresetType, { name: string, blur: number, threshold: number, strokeStyle: string, lineWidth: number }> = {
  light_ink: { name: "Light Sketch", blur: 3, threshold: 242, strokeStyle: 'rgba(50, 50, 60, 0.5)', lineWidth: 0.85 },
  classic_graphite: { name: "Graphite", blur: 4, threshold: 247, strokeStyle: 'rgba(30, 30, 40, 0.6)', lineWidth: 1.0 },
  dark_charcoal: { name: "Charcoal", blur: 6, threshold: 251, strokeStyle: 'rgba(20, 20, 25, 0.7)', lineWidth: 1.2 }
};

export default function App() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [hasCanvasData, setHasCanvasData] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [activePreset, setActivePreset] = useState<PresetType>('classic_graphite');
  const [currentFile, setCurrentFile] = useState<File | null>(null);
  const [originalImgUrl, setOriginalImgUrl] = useState<string | null>(null);
  const [comparePosition, setComparePosition] = useState(50);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pencilCanvasRef = useRef<HTMLCanvasElement>(null);
  const viewContainerRef = useRef<HTMLDivElement>(null);
  const animRef = useRef<gsap.core.Tween | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const cameraParams = useRef({ x: 50, y: 50, scale: 1 });
  const targetCameraParams = useRef({ x: 50, y: 50, scale: 1 });
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const speedRef = useRef(1);

  const drawingState = useRef<{
    pixels: { x: number; y: number; isStart?: boolean }[];
    lastIndex: number;
    width: number;
    height: number;
    presetConf: any;
  }>({
    pixels: [],
    lastIndex: 0,
    width: 0,
    height: 0,
    presetConf: null,
  });

  // --- AUDIO LOGIC ---
  useEffect(() => {
     const audio = new Audio("https://files.catbox.moe/jvg09b.mp3");
     audio.loop = true;
     audio.preload = "auto";
     audioRef.current = audio;
     
     return () => {
         audio.pause();
         audio.src = "";
     };
  }, []);

  const getAudioCtx = () => {
      // Audio context is no longer needed since we are using HTMLAudioElement,
      // but keeping this stub to avoid breaking existing event handlers that call it.
      if (audioRef.current && audioRef.current.paused) {
          // just to ensure browser constraints on play are satisfied on interactions
      }
  };

  const startAudio = () => {
      if (audioRef.current) {
          audioRef.current.playbackRate = Math.max(0.1, speedRef.current);
          audioRef.current.play().catch(e => console.log("Audio play failed, likely requires interaction first:", e));
      }
  };

  const stopAudio = () => {
      if (audioRef.current) {
          audioRef.current.pause();
          // avoid resetting to 0 to make it seamless if replayed from middle
      }
  };

  // Sync speed changes to animation and audio
  useEffect(() => {
    speedRef.current = speedMultiplier;
    
    if (animRef.current) {
      animRef.current.timeScale(speedMultiplier);
    }
    
    if (audioRef.current && isDrawing) {
        audioRef.current.playbackRate = Math.max(0.1, speedMultiplier);
    }
  }, [speedMultiplier, isDrawing]);

  // Clean object URL on unmount
  useEffect(() => {
    return () => {
      if (originalImgUrl) URL.revokeObjectURL(originalImgUrl);
    };
  }, [originalImgUrl]);

  // --- CAMERA LOGIC ---
  useEffect(() => {
    const onTick = () => {
        if (!isDrawing) return;
        const c = cameraParams.current;
        const t = targetCameraParams.current;
        c.x += (t.x - c.x) * 0.05;
        c.y += (t.y - c.y) * 0.05;
        c.scale += (t.scale - c.scale) * 0.05;
        
        if (viewContainerRef.current) {
            viewContainerRef.current.style.transformOrigin = `${c.x}% ${c.y}%`;
            viewContainerRef.current.style.transform = `scale(${c.scale})`;
        }
    };
    gsap.ticker.add(onTick);
    return () => gsap.ticker.remove(onTick);
  }, [isDrawing]);

  const resetCamera = () => {
      if (viewContainerRef.current) {
          gsap.killTweensOf(viewContainerRef.current);
          viewContainerRef.current.style.transform = `scale(1)`;
          viewContainerRef.current.style.transformOrigin = `50% 50%`;
          cameraParams.current = { x: 50, y: 50, scale: 1 };
          targetCameraParams.current = { x: 50, y: 50, scale: 1 };
      }
  };

  const clearCanvas = () => {
    if (animRef.current) animRef.current.kill();
    resetCamera();
    stopAudio();
    
    setHasCanvasData(false);
    setIsDrawing(false);
    setProgress(0);
    setComparePosition(50);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setCurrentFile(null);
    
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
    if (pencilCanvasRef.current) {
      const pencilCtx = pencilCanvasRef.current.getContext('2d');
      if (pencilCtx) pencilCtx.clearRect(0, 0, pencilCanvasRef.current.width, pencilCanvasRef.current.height);
    }
  };

  // --- IMAGE PROCESSING LOGIC ---
  const processImage = async (file: File, srcUrl: string, presetKey: PresetType) => {
    setIsProcessing(true);
    setHasCanvasData(false);
    setProgress(0);
    setIsDrawing(false);
    setComparePosition(50);
    resetCamera();
    stopAudio();
    
    if (animRef.current) {
      animRef.current.kill();
    }

    try {
      const img = new Image();
      img.src = srcUrl;
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      await new Promise(r => setTimeout(r, 50)); // yield for paint

      const MAX_DIM = 1000;
      let width = img.width;
      let height = img.height;
      if (width > MAX_DIM || height > MAX_DIM) {
        const ratio = Math.min(MAX_DIM / width, MAX_DIM / height);
        width = Math.floor(width * ratio);
        height = Math.floor(height * ratio);
      }

      const offCanvas = document.createElement('canvas');
      offCanvas.width = width;
      offCanvas.height = height;
      const ctx = offCanvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) throw new Error("Could not get 2D context");

      const conf = PRESETS[presetKey];

      // 1. Native Image Filtering and Edge Extraction via Canvas API
      // First, we draw the original image with high contrast and slight blur to drop noise/pores
      const off1 = document.createElement('canvas');
      off1.width = width;
      off1.height = height;
      const ctx1 = off1.getContext('2d', { willReadFrequently: true });
      if (!ctx1) throw new Error("Could not get 2D context");
      
      ctx1.filter = 'grayscale(100%) blur(0.5px) contrast(1.2) brightness(1.05)';
      ctx1.drawImage(img, 0, 0, width, height);

      // Second, create an inverted and mathematically blurred version based on preset thickness
      const off2 = document.createElement('canvas');
      off2.width = width;
      off2.height = height;
      const ctx2 = off2.getContext('2d');
      if (!ctx2) throw new Error("Could not get 2D context");
      
      ctx2.filter = `invert(100%) blur(${conf.blur}px)`;
      ctx2.drawImage(off1, 0, 0, width, height);

      // Third, combine using Color Dodge to mathematically isolate pure edge geometry
      const off3 = document.createElement('canvas');
      off3.width = width;
      off3.height = height;
      const ctx3 = off3.getContext('2d', { willReadFrequently: true });
      if (!ctx3) throw new Error("Could not get 2D context");
      
      ctx3.drawImage(off1, 0, 0, width, height);
      ctx3.globalCompositeOperation = 'color-dodge';
      ctx3.drawImage(off2, 0, 0, width, height);

      // Extract raw pixel data containing the isolated sketch paths
      const imageData = ctx3.getImageData(0, 0, width, height).data;
      const sketchPixels = new Float32Array(width * height);
      for (let i = 0; i < width * height; i++) {
          sketchPixels[i] = imageData[i * 4]; // R channel is sufficient for grayscale
      }

      // 2. Continuous Path Extraction (DFS for human-like lines)
      const paths: { x: number; y: number }[][] = [];
      const threshold = conf.threshold || 240;
      
      const available = new Uint8Array(width * height);
      for (let i = 0; i < width * height; i++) {
          if (sketchPixels[i] < threshold) {
              available[i] = 1;
          }
      }

      for (let y = 0; y < height; y++) {
          for (let x = 0; x < width; x++) {
              if (available[y * width + x] === 1) {
                  const path: { x: number; y: number }[] = [];
                  let currX = x;
                  let currY = y;
                  
                  while (true) {
                      path.push({ x: currX, y: currY });
                      available[currY * width + currX] = 0;
                      
                      let nextX = -1;
                      let nextY = -1;
                      let minVal = Infinity;
                      
                      // 1. Prioritize tracing the darkest connecting path immediately next to the pencil
                      const immediateNeighbors = [
                         [1, 0], [1, 1], [0, 1], [-1, 1],
                         [-1, 0], [-1, -1], [0, -1], [1, -1]
                      ];
                      
                      for (const [dx, dy] of immediateNeighbors) {
                          const nx = currX + dx;
                          const ny = currY + dy;
                          if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                              const nIdx = ny * width + nx;
                              if (available[nIdx] === 1) {
                                  const val = sketchPixels[nIdx];
                                  if (val < minVal) {
                                      minVal = val;
                                      nextX = nx;
                                      nextY = ny;
                                  }
                              }
                          }
                      }
                      
                      // 2. Human tendency to skip small gaps to continue a straight-ish line (up to 3px radius)
                      if (nextX === -1) {
                          for (let radius = 2; radius <= 3; radius++) {
                              let gapMinVal = Infinity;
                              for (let dy = -radius; dy <= radius; dy++) {
                                  for (let dx = -radius; dx <= radius; dx++) {
                                      if (Math.abs(dx) < radius && Math.abs(dy) < radius) continue;
                                      const nx = currX + dx;
                                      const ny = currY + dy;
                                      if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                                          const nIdx = ny * width + nx;
                                          if (available[nIdx] === 1) {
                                              const val = sketchPixels[nIdx];
                                              if (val < gapMinVal) {
                                                  gapMinVal = val;
                                                  nextX = nx;
                                                  nextY = ny;
                                              }
                                          }
                                      }
                                  }
                              }
                              if (nextX !== -1) break;
                          }
                      }
                      
                      if (nextX !== -1) {
                          currX = nextX;
                          currY = nextY;
                      } else {
                          break;
                      }
                  }
                  
                  if (path.length > 1) { // Discard isolated single-pixel noise artifacts 
                      paths.push(path);
                  }
              }
          }
      }

      // Draw longest continuous outlines first (human sketching technique)
      paths.sort((a, b) => b.length - a.length);

      // 3. Generate Shading/Hatching Paths for Shadows
      const grayscaleImageData = ctx1.getImageData(0, 0, width, height).data;
      const grayscalePixels = new Uint8Array(width * height);
      for (let i = 0; i < width * height; i++) {
          grayscalePixels[i] = grayscaleImageData[i * 4];
      }

      const shadingPaths: { x: number; y: number }[][] = [];
      const SHADOW_THRESHOLD_1 = 150; // Mid-tones
      const SHADOW_THRESHOLD_2 = 90;  // Core shadows
      const SHADOW_THRESHOLD_3 = 45;  // Deepest shadows
      
      const generateHatching = (angle: number, spacing: number, threshold: number, jitter: number) => {
          const cosA = Math.cos(angle);
          const sinA = Math.sin(angle);
          const maxDist = Math.sqrt(width * width + height * height);
          
          for (let d = -maxDist; d < maxDist; d += spacing) {
              let currentPath: { x: number; y: number }[] = [];
              
              for (let t = -maxDist; t < maxDist; t += 1.5) {
                  let px = d * cosA - t * sinA;
                  let py = d * sinA + t * cosA;
                  
                  // Human jitter
                  px += (Math.random() - 0.5) * jitter;
                  py += (Math.random() - 0.5) * jitter;
                  
                  const intX = Math.round(px);
                  const intY = Math.round(py);
                  
                  if (intX >= 0 && intX < width && intY >= 0 && intY < height) {
                      const val = grayscalePixels[intY * width + intX];
                      
                      // Check edge proximity to avoid drawing shading outside of actual dark areas
                      if (val < threshold) {
                          currentPath.push({ x: px, y: py });
                      } else {
                          if (currentPath.length > 3) shadingPaths.push(currentPath);
                          currentPath = [];
                      }
                  } else {
                      if (currentPath.length > 3) shadingPaths.push(currentPath);
                      currentPath = [];
                  }
              }
              if (currentPath.length > 3) shadingPaths.push(currentPath);
          }
      };

      // 45 deg, -45 deg, and near vertical/horizontal for cross-hatching
      generateHatching(Math.PI / 4, 5, SHADOW_THRESHOLD_1, 1.5);
      generateHatching(-Math.PI / 4, 4.5, SHADOW_THRESHOLD_2, 1.5);
      generateHatching(Math.PI / 12, 4, SHADOW_THRESHOLD_3, 2.0);

      // Randomize shading paths to simulate human jumping around the canvas to fill shadows
      shadingPaths.sort(() => Math.random() - 0.5);

      const orderedPixels: { x: number; y: number; isStart?: boolean }[] = [];
      
      // Draw outlines first
      for (const path of paths) {
          for (let i = 0; i < path.length; i++) {
              orderedPixels.push({ x: path[i].x, y: path[i].y, isStart: i === 0 });
          }
      }
      
      // Then draw shading
      for (const path of shadingPaths) {
          for (let i = 0; i < path.length; i++) {
              orderedPixels.push({ x: path[i].x, y: path[i].y, isStart: i === 0 });
          }
      }

      drawingState.current = {
        pixels: orderedPixels,
        lastIndex: 0,
        width,
        height,
        presetConf: conf
      };

      if (canvasRef.current && pencilCanvasRef.current) {
        canvasRef.current.width = width;
        canvasRef.current.height = height;
        pencilCanvasRef.current.width = width;
        pencilCanvasRef.current.height = height;
        
        const viewCtx = canvasRef.current.getContext('2d');
        if (viewCtx) {
            viewCtx.fillStyle = '#ffffff';
            viewCtx.fillRect(0, 0, width, height);
        }
      }

      setHasCanvasData(true);
      startAnimation();
      
    } catch (e) {
      console.error(e);
      alert("Failed to process image.");
    } finally {
      setIsProcessing(false);
    }
  };

  const startAnimation = useCallback(() => {
    const { pixels, width, height } = drawingState.current;
    if (!pixels.length || !canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    const pencilCtx = pencilCanvasRef.current?.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
    drawingState.current.lastIndex = 0;
    setProgress(0);
    setIsDrawing(true);
    setComparePosition(50);
    resetCamera();
    startAudio();

    if (animRef.current) {
      animRef.current.kill();
    }
    
    if (pencilCtx) pencilCtx.clearRect(0, 0, width, height);

    const state = { progress: 0 };
    const tween = gsap.to(state, {
      progress: 1,
      duration: 6.5,
      ease: "power2.inOut",
      onUpdate: () => {
        setProgress(state.progress);
        const targetIndex = Math.floor(state.progress * pixels.length);
        const lastIndex = drawingState.current.lastIndex;

        if (targetIndex > lastIndex) {
            ctx.beginPath();
            ctx.strokeStyle = drawingState.current.presetConf?.strokeStyle || 'rgba(30, 30, 35, 0.45)';
            ctx.lineWidth = drawingState.current.presetConf?.lineWidth || 1.2;
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';

            for (let i = lastIndex; i < targetIndex; i++) {
                const p = pixels[i];
                if (p.isStart) {
                    ctx.moveTo(p.x, p.y);
                } else {
                    if (i === lastIndex && i > 0 && !p.isStart) {
                        ctx.moveTo(pixels[i-1].x, pixels[i-1].y);
                    }
                    ctx.lineTo(p.x, p.y);
                }
            }
            ctx.stroke();

            drawingState.current.lastIndex = targetIndex;
            
            if (pencilCtx && targetIndex > 0 && targetIndex < pixels.length) {
                 pencilCtx.clearRect(0, 0, width, height); 
                 const currentPixel = pixels[targetIndex - 1];
                 drawPencil(pencilCtx, currentPixel.x, currentPixel.y, width);
                 
                 // Feed camera
                 targetCameraParams.current.x = (currentPixel.x / width) * 100;
                 targetCameraParams.current.y = (currentPixel.y / height) * 100;
                 
                 if (state.progress > 0.05 && state.progress < 0.85) {
                    targetCameraParams.current.scale = 1.15; 
                 } else {
                    targetCameraParams.current.scale = 1;
                    targetCameraParams.current.x = 50;
                    targetCameraParams.current.y = 50;
                 }
            }
        }
      },
      onComplete: () => {
        setIsDrawing(false);
        setProgress(1);
        if (pencilCtx) pencilCtx.clearRect(0, 0, width, height);
        stopAudio();
        
        // Cinematic finale zoom out
        if (viewContainerRef.current) {
             gsap.to(viewContainerRef.current, {
                 scale: 1,
                 duration: 1.5,
                 ease: "power2.out",
             });
        }
      }
    });

    tween.timeScale(speedRef.current);
    animRef.current = tween;
  }, []);

  // --- EVENT HANDLERS ---
  const handleNewFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert("Please upload a valid image file.");
      return;
    }
    // ensure audio ctx builds upon explicit user interaction
    getAudioCtx();
    
    if (originalImgUrl) URL.revokeObjectURL(originalImgUrl);
    const url = URL.createObjectURL(file);
    setOriginalImgUrl(url);
    setCurrentFile(file);
    processImage(file, url, activePreset);
  };

  const handlePresetChange = (preset: PresetType) => {
    setActivePreset(preset);
    if (currentFile && originalImgUrl) {
      processImage(currentFile, originalImgUrl, preset);
    }
  };

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = 'anime-sketch.png';
    a.click();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleNewFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleNewFile(e.target.files[0]);
    }
    e.target.value = '';
  };

  const triggerFileInput = () => {
    // ensure audio ctx builds upon explicit user interaction
    getAudioCtx();
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-zinc-100 font-sans selection:bg-indigo-500/30 flex flex-col relative overflow-hidden">
      
      {/* Cinematic ambient grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293706_1px,transparent_1px),linear-gradient(to_bottom,#1f293706_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>
      
      {/* Soft elegant color glows */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[40%] bg-indigo-500/[0.04] blur-[160px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[40%] bg-zinc-500/[0.02] blur-[160px] rounded-full pointer-events-none"></div>

      {/* Modern Top Navigation bar */}
      <header className="w-full flex items-center justify-between px-6 py-4 z-10 border-b border-zinc-950 bg-[#07080a]/40 backdrop-blur-md">
         <div className="flex items-center gap-3">
             <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-zinc-850 to-zinc-950 flex items-center justify-center p-0.5 border border-zinc-800/40 shadow-lg animate-fade-in">
                <Sparkles className="w-4 h-4 text-indigo-400" strokeWidth={1.5} />
             </div>
             <div>
                <h1 className="text-sm font-semibold tracking-tight text-white leading-none font-display">Anime Sketch</h1>
                <p className="text-[9px] text-indigo-400/80 font-mono tracking-widest uppercase mt-0.5">Vector Animator Studio</p>
             </div>
         </div>
         
         <div className="flex items-center gap-4">
             {/* Micro status badge */}
             <div className="flex items-center gap-1.5 px-3 py-1 bg-zinc-900/20 border border-zinc-850/60 rounded-full">
                <span className={`w-1.5 h-1.5 rounded-full ${isProcessing ? 'bg-indigo-500 animate-pulse shadow-[0_0_10px_rgba(99,102,241,0.4)]' : isDrawing ? 'bg-amber-400 animate-pulse shadow-[0_0_10px_rgba(245,158,11,0.4)]' : hasCanvasData ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.4)]' : 'bg-zinc-700'}`}></span>
                <span className="text-[10px] font-mono tracking-wide text-zinc-400">
                    {isProcessing ? 'TRANSFORMING_IMAGE' : isDrawing ? 'ACTIVE_TRACE_DRAW' : hasCanvasData ? 'GEOMETRY_FITTED' : 'SYSTEM_READY'}
                </span>
             </div>
             {hasCanvasData && (
                <button 
                  id="btn-clear-project"
                  onClick={clearCanvas} 
                  className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-all rounded-lg border border-transparent hover:border-red-950/20"
                  title="Clear Project"
                >
                   <Trash2 className="w-3.5 h-3.5" />
                </button>
             )}
         </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto flex flex-col justify-center px-6 py-10 z-10">
        
        {/* Empty State / Upload Dropzone */}
        {!hasCanvasData && !isProcessing && (
          <div className="max-w-xl w-full mx-auto flex flex-col items-center">
            {/* Minimal introduction banner */}
            <div className="text-center mb-8">
              <span className="text-[9px] font-mono tracking-[0.25em] text-indigo-400 bg-indigo-950/20 border border-indigo-900/40 px-3.5 py-1.5 rounded-full uppercase">Depth Path Reconstruction</span>
              <h2 className="text-4xl font-semibold font-display tracking-tight text-white mt-4 mb-3">Instant Line-Art Animation</h2>
              <p className="text-zinc-400 text-sm leading-relaxed font-sans max-w-md mx-auto font-light">
                Upload sketches, portraits, or doodles. Our engine automatically translates curves and animates them with realistic handwriting gestures.
              </p>
            </div>

            <div 
              className={`w-full relative rounded-3xl overflow-hidden transition-all duration-500 ease-out transform group
                ${isDragging ? 'scale-[1.01] bg-indigo-500/[0.03] border-indigo-500/40 shadow-[0_0_50px_rgba(99,102,241,0.05)]' : 'scale-100 bg-[#121318]/50 border-zinc-900/80 hover:border-zinc-800 hover:bg-[#14151B]/80 hover:shadow-[0_0_40px_rgba(255,255,255,0.015)]'}
                border-[1.5px]`}
            >
              <div 
                className="flex flex-col items-center justify-center p-16 cursor-pointer"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={triggerFileInput}
              >
                 <div className="bg-zinc-900/40 p-5 rounded-2xl mb-6 border border-zinc-850/60 group-hover:scale-102 group-hover:border-zinc-700/60 transition-all duration-500 shadow-md">
                   <UploadCloud className="w-7 h-7 text-zinc-400 group-hover:text-indigo-400 transition-colors" strokeWidth={1.5} />
                 </div>
                 <h3 className="text-base font-medium text-zinc-200 mb-1 font-display">Select an artwork file</h3>
                 <p className="text-xs text-zinc-500 mb-6 font-mono tracking-wide text-center">
                    Drag & drop anywhere or click to index
                 </p>
                 
                 <button className="bg-indigo-500 hover:bg-indigo-400 text-white font-semibold py-2.5 px-6 rounded-xl transition-all shadow-md text-xs flex items-center gap-2">
                   <ImageIcon className="w-3.5 h-3.5" />
                   Choose Graphic File
                 </button>
                 <input 
                   ref={fileInputRef}
                   type="file" 
                   accept="image/*" 
                   className="hidden" 
                   onChange={handleFileInput} 
                 />
              </div>
            </div>
          </div>
        )}

        {/* Processing State */}
        {isProcessing && (
          <div className="w-full max-w-sm mx-auto py-16 px-8 flex flex-col items-center justify-center rounded-3xl bg-[#121318]/90 border border-zinc-850/60 backdrop-blur-xl shadow-2xl">
             <div className="relative mb-6">
                 <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full"></div>
                 <Loader2 className="w-8 h-8 text-indigo-400 animate-spin relative z-10" strokeWidth={1.5} />
             </div>
             <h3 className="text-sm font-medium tracking-tight text-white mb-1.5 font-display">Isolating Path Matrix</h3>
             <p className="text-indigo-400/80 font-mono text-[9px] uppercase tracking-widest animate-pulse">Running depth-first outline solver...</p>
          </div>
        )}

        {/* Display Canvas & Controls */}
        <div className={`w-full flex flex-col xl:flex-row items-stretch justify-center gap-10 transition-all duration-700 ${hasCanvasData && !isProcessing ? 'opacity-100 translate-y-0' : 'hidden opacity-0 translate-y-8'}`}>
          
          {/* Main Visual Frame (Canvas) */}
          <div className="flex-1 min-w-0 flex flex-col justify-center">
             <div className="relative p-1 bg-[#121318]/40 rounded-2xl border border-zinc-900/60 shadow-2xl flex-1 flex flex-col justify-center min-h-[50vh] xl:min-h-[64vh]">
                 
                 {/* The Sketch Paper container */}
                 <div className="bg-[#FAF9F6] rounded-xl overflow-hidden relative shadow-inner flex items-center justify-center w-full h-full">
                 
                 <div ref={viewContainerRef} className="relative w-full h-full">
                     <canvas 
                       ref={canvasRef} 
                       className="w-full h-auto max-h-[60vh] object-contain mix-blend-multiply opacity-90 mx-auto block origin-center"
                       style={{ backgroundColor: 'transparent' }}
                     />
                     <canvas
                       ref={pencilCanvasRef}
                       className="w-full h-auto max-h-[60vh] object-contain absolute top-0 left-0 right-0 bottom-0 pointer-events-none mx-auto block z-20 origin-center"
                     />
                 </div>
                 
                 {/* Compare Canvas Overlay (Revealed at 100%) */}
                 {progress === 1 && !isDrawing && originalImgUrl && (
                     <div className="absolute inset-0 select-none overflow-hidden rounded-lg z-30">
                         <div 
                            className="absolute inset-0 pointer-events-none"
                            style={{ clipPath: `polygon(0 0, ${comparePosition}% 0, ${comparePosition}% 100%, 0 100%)` }}
                         >
                            <img src={originalImgUrl} className="w-full h-full object-contain mx-auto mix-blend-normal opacity-100" draggable="false" />
                         </div>
                         
                         <div 
                            className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize shadow-[0_0_15px_rgba(0,0,0,0.5)] z-20 pointer-events-none group-hover:bg-zinc-200 transition-colors"
                            style={{ left: `${comparePosition}%`, transform: 'translateX(-50%)' }}
                         >
                             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-zinc-900 backdrop-blur rounded-full border-2 border-white flex items-center justify-center shadow-2xl">
                                  <span className="text-[10px] text-white font-bold tracking-tighter w-full text-center scale-x-75">||</span>
                             </div>
                             
                             {comparePosition === 50 && (
                                  <div className="absolute top-[60%] left-1/2 -translate-x-1/2 px-2 py-1 bg-zinc-900/80 text-white text-[10px] rounded shadow-lg whitespace-nowrap animate-pulse font-mono tracking-wide mt-4">
                                      DRAG TO COMPARE
                                  </div>
                             )}
                         </div>
                         
                         <input 
                            type="range" min="0" max="100" value={comparePosition}
                            onChange={(e) => setComparePosition(parseFloat(e.target.value))}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30 m-0"
                         />
                     </div>
                 )}

                 {/* Soft organic paper texture overlay */}
                  <div className="absolute inset-0 pointer-events-none opacity-[0.035] mix-blend-multiply z-10" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>
              </div>
           </div>
          </div>

          {/* Side Control Inspector panels */}
          <div className="w-full xl:w-[350px] flex flex-col gap-6 shrink-0">
                 
                 {/* Presets Toggle Block */}
                 <div className="p-5 bg-[#121318]/60 border border-zinc-900 rounded-2xl shadow-inner">
                     <span className="block text-[10px] text-zinc-500 font-mono tracking-widest uppercase mb-3.5">Styling preset</span>
                     <div className="flex flex-col gap-1.5 font-sans">
                        {(Object.keys(PRESETS) as PresetType[]).map((preset) => (
                            <button
                               key={preset}
                               onClick={() => handlePresetChange(preset)}
                               disabled={isDrawing}
                               className={`text-left px-4 py-3 rounded-xl transition-all duration-300 border disabled:opacity-40 flex flex-col relative overflow-hidden group
                                  ${activePreset === preset ? 'bg-white text-zinc-950 border-white shadow-[0_4px_20px_rgba(255,255,255,0.08)]' : 'bg-[#15161D]/50 text-zinc-400 border-zinc-900/80 hover:bg-[#181920]/80 hover:border-zinc-850'}`}
                            >
                               <span className="text-xs font-semibold font-sans">{PRESETS[preset].name}</span>
                               <span className={`text-[10px] mt-0.5 font-mono ${activePreset === preset ? 'text-zinc-600' : 'text-zinc-500'}`}>
                                  {preset === 'light_ink' ? 'Thin fine outline' : preset === 'classic_graphite' ? 'Standard graphite density' : 'Bold shading and coal grit'}
                                </span>
                               {activePreset === preset && (
                                   <div className="absolute right-4 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-zinc-950"></div>
                               )}
                            </button>
                        ))}
                     </div>
                 </div>

                 {/* Playback parameters panel */}
                 <div className="p-5 bg-[#121318]/60 border border-zinc-900 rounded-2xl space-y-5">
                     
                     {/* Speed Slider */}
                     <div>
                         <div className="flex justify-between items-center mb-3">
                            <span className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">Drawing velocity</span>
                            <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/20 px-2 py-0.5 rounded border border-indigo-900/40">{speedMultiplier.toFixed(1)}x</span>
                         </div>
                         <input 
                           type="range" min="0.2" max="5" step="0.1" value={speedMultiplier}
                           onChange={(e) => setSpeedMultiplier(parseFloat(e.target.value))}
                           className="w-full h-1 bg-zinc-900 rounded-full appearance-none cursor-pointer accent-indigo-400 hover:accent-indigo-300 transition-all outline-none"
                         />
                         <div className="flex justify-between text-[9px] text-[#4b4e54] font-mono mt-2">
                             <span>0.2x</span>
                             <span>1.0x (Classic)</span>
                             <span>5.0x</span>
                         </div>
                     </div>

                     {/* Progress tracker */}
                     <div className="pt-4 border-t border-zinc-900/60">
                         <div className="flex justify-between items-end mb-2">
                            <span className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">Trace progress</span>
                            <span className={`text-sm font-semibold font-mono tracking-tight transition-colors ${progress === 1 ? 'text-emerald-400 font-bold' : 'text-zinc-300'}`}>
                               {Math.round(progress * 100)}%
                            </span>
                         </div>
                         <div className="w-full h-1 bg-zinc-950 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-indigo-400 transition-all duration-75 ease-out relative shadow-[0_0_8px_rgba(129,140,248,0.5)]"
                              style={{ width: `${progress * 105 <= 100 ? progress * 100 : 100}%` }}
                            />
                         </div>
                     </div>

                 </div>

                 {/* Control buttons block */}
                 <div className="p-5 bg-[#121318]/60 border border-zinc-900 rounded-2xl flex flex-col gap-2">
                     <button 
                       id="btn-replay"
                       onClick={startAnimation} 
                       disabled={isDrawing || progress === 0}
                       className="w-full py-2.5 bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-[0_4px_20px_rgba(99,102,241,0.2)] hover:bg-indigo-400 disabled:opacity-40 disabled:bg-zinc-850 disabled:text-zinc-500 disabled:shadow-none disabled:cursor-not-allowed flex justify-center items-center gap-2 group active:scale-[0.98] border border-indigo-600/20"
                     >
                       <RefreshCw className={`w-3.5 h-3.5 ${isDrawing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-700'}`} />
                       Replay Draw-Trace
                     </button>
                     
                     <button 
                       id="btn-download"
                       onClick={handleDownload} 
                       disabled={isDrawing || progress < 1}
                       className="w-full py-2.5 bg-[#16171F] border border-zinc-850 text-zinc-300 text-xs font-medium rounded-xl transition-all disabled:opacity-30 hover:bg-zinc-900 hover:text-white disabled:cursor-not-allowed flex justify-center items-center gap-1.5 active:scale-[0.98]"
                     >
                       <Download className="w-3.5 h-3.5" />
                       Download png
                     </button>
                 </div>

          </div>
        </div>
      </main>
    </div>
  );
}
