const fs = require('fs');
fs.copyFileSync('./anime/src/App.tsx', './src/App.tsx');
