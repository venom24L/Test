import fs from 'fs';
fs.copyFileSync('/anime/src/App.tsx', '/src/App.tsx');
console.log('Copied successfully!');
