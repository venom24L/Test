import fs from 'fs';

const orig = fs.readFileSync('./anime/src/App.tsx', 'utf-8');
const logicIdx = orig.indexOf('return (');
const logic = orig.substring(0, logicIdx);

const newUI = `return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 font-sans selection:bg-zinc-800 flex flex-col relative overflow-hidden">
      
      {/* Dynamic Background Noise */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.015] z-0" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>

      {/* Modern Top Header */}
      <header className="w-full flex items-center justify-between p-6 z-10 border-b border-white/5 bg-black/20 backdrop-blur-md">
         <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-zinc-800 to-zinc-700 flex items-center justify-center p-0.5 shadow-lg border border-white/10">
                <div className="w-full h-full bg-[#0a0a0a] rounded-[10px] flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" strokeWidth={1.5} />
                </div>
             </div>
             <div>
                <h1 className="text-xl font-medium tracking-tight text-white leading-tight">Anime Sketch</h1>
                <p className="text-xs text-zinc-500 font-mono tracking-wide uppercase">AI Animator Studio</p>
             </div>
         </div>
         {hasCanvasData && (
             <div className="flex items-center gap-2">
                 <button onClick={clearCanvas} className="p-2 text-zinc-500 hover:text-white transition-colors rounded-full hover:bg-white/5">
                     <Trash2 className="w-4 h-4" />
                 </button>
             </div>
         )}
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto flex flex-col items-center justify-center p-6 md:p-12 z-10">
        
        {/* Empty State / Upload Dropzone */}
        {!hasCanvasData && !isProcessing && (
          <div 
            className={\`w-full max-w-xl relative rounded-[2rem] overflow-hidden transition-all duration-500 ease-out transform
              \${isDragging ? 'scale-[1.02] bg-white/5 border-white/30 shadow-2xl' : 'scale-100 bg-white/[0.02] border-white/10 hover:border-white/20 hover:bg-white/[0.03]'}
            \`}
          >
            <div 
              className="flex flex-col items-center justify-center p-20 border-[1.5px] border-transparent cursor-pointer rounded-[2rem]"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={triggerFileInput}
            >
               <div className="bg-white/5 p-6 rounded-3xl mb-8 border border-white/10 group-hover:scale-105 transition-transform duration-500">
                 <UploadCloud className="w-10 h-10 text-white" strokeWidth={1} />
               </div>
               <h3 className="text-2xl font-light text-white mb-3">Upload your artwork</h3>
               <p className="text-sm text-zinc-500 mb-8 font-mono text-center max-w-xs leading-relaxed">
                  Drag and drop any image here to dynamically trace and animate a clean sketch.
               </p>
               
               <button className="bg-white text-black font-semibold py-3 px-8 rounded-full transition-all hover:scale-105 flex items-center gap-2 text-sm shadow-[0_0_20px_rgba(255,255,255,0.1)]">
                 <ImageIcon className="w-4 h-4" />
                 Browse Files
               </button>
               <input 
                 ref={fileInputRef}
                 type="file" 
                 accept="image/*" 
                 className="hidden" 
                 onChange={handleFileInput} 
               />
            </div>
          </div>
        )}

        {/* Processing State */}
        {isProcessing && (
          <div className="w-full max-w-xl p-24 flex flex-col items-center justify-center rounded-[2rem] bg-white/[0.02] border border-white/5 backdrop-blur-xl shadow-2xl">
             <div className="relative mb-8">
                 <div className="absolute inset-0 bg-white/20 blur-xl rounded-full"></div>
                 <RefreshCw className="w-10 h-10 text-white animate-spin relative z-10" strokeWidth={1.5} />
             </div>
             <h3 className="text-xl font-medium tracking-tight text-white mb-2">Analyzing Image</h3>
             <p className="text-zinc-500 font-mono text-xs uppercase tracking-widest animate-pulse">Extracting geometry...</p>
          </div>
        )}

        {/* Display Canvas & Controls */}
        <div className={\`w-full flex flex-col xl:flex-row items-center xl:items-start justify-center gap-8 xl:gap-16 transition-all duration-1000 \${hasCanvasData && !isProcessing ? 'opacity-100 translate-y-0' : 'hidden opacity-0 translate-y-12'}\`}>
          
          {/* Main Visual Frame */}
          <div className="relative flex-1 w-full max-w-4xl p-1 md:p-3 bg-zinc-900/50 backdrop-blur-3xl rounded-[2.5rem] border border-white/10 shadow-2xl">
             
             {/* The Sketch Paper */}
             <div className="bg-[#FAF9F6] rounded-[2rem] overflow-hidden relative shadow-inner group aspect-auto min-h-[50vh] flex items-center justify-center">
                 
                 <div ref={viewContainerRef} className="relative w-full h-full flex items-center justify-center">
                     <canvas 
                       ref={canvasRef} 
                       className="w-full h-auto max-h-[75vh] object-contain mix-blend-multiply opacity-90 mx-auto block origin-center"
                       style={{ backgroundColor: 'transparent' }}
                     />
                     <canvas
                       ref={pencilCanvasRef}
                       className="w-full h-auto max-h-[75vh] object-contain absolute top-0 left-0 right-0 bottom-0 pointer-events-none mx-auto block z-20 origin-center"
                     />
                 </div>
                 
                 {/* Compare Canvas */}
                 {progress === 1 && !isDrawing && originalImgUrl && (
                     <div className="absolute inset-0 select-none overflow-hidden rounded-[2rem] z-30">
                         <div 
                            className="absolute inset-0 pointer-events-none"
                            style={{ clipPath: \`polygon(0 0, \${comparePosition}% 0, \${comparePosition}% 100%, 0 100%)\` }}
                         >
                            <img src={originalImgUrl} className="w-full h-full object-contain mx-auto mix-blend-normal opacity-100" draggable="false" />
                         </div>
                         
                         <div 
                            className="absolute top-0 bottom-0 w-0.5 bg-white cursor-ew-resize mix-blend-difference z-20 pointer-events-none"
                            style={{ left: \`\${comparePosition}%\`, transform: 'translateX(-50%)' }}
                         >
                             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 backdrop-blur-lg rounded-full border border-white/20 flex flex-col items-center justify-center shadow-2xl gap-0.5 text-white">
                                 <div className="w-[1px] h-3 bg-white/60"></div>
                                 <div className="w-[1px] h-3 bg-white/60"></div>
                             </div>
                             
                             {comparePosition === 50 && (
                                 <div className="absolute top-[65%] left-1/2 -translate-x-1/2 px-3 py-1.5 bg-black/50 backdrop-blur-md border border-white/10 text-white text-[10px] rounded-full whitespace-nowrap animate-bounce font-mono tracking-widest mt-4">
                                     SLIDE TO COMPARE
                                 </div>
                             )}
                         </div>
                         
                         <input 
                            type="range" min="0" max="100" value={comparePosition}
                            onChange={(e) => setComparePosition(parseFloat(e.target.value))}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30 m-0"
                         />
                     </div>
                 )}

                 <div className="absolute inset-0 pointer-events-none opacity-[0.02] mix-blend-multiply z-10" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.8%22 numOctaves=%224%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>
             </div>
          </div>

          {/* Side Inspector Controls */}
          <div className="w-full xl:w-80 flex flex-col gap-6">
              
              {/* Tool Settings Card */}
              <div className="p-6 bg-white/[0.02] border border-white/10 rounded-3xl backdrop-blur-xl">
                 <h4 className="text-xs font-mono font-medium text-white uppercase tracking-widest mb-6 flex items-center justify-between">
                     Settings
                     <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
                 </h4>
                 
                 {/* Preset Toggle */}
                 <div className="mb-8">
                     <span className="block text-xs text-zinc-500 mb-3">Graphite Style</span>
                     <div className="flex flex-col gap-2">
                        {(Object.keys(PRESETS) as PresetType[]).map((preset) => (
                            <button
                               key={preset}
                               onClick={() => handlePresetChange(preset)}
                               disabled={isDrawing}
                               className={\`text-left px-4 py-3 rounded-2xl text-sm font-medium transition-all duration-300 border disabled:opacity-40
                                  \${activePreset === preset ? 'bg-white text-black border-white shadow-xl scale-[1.02]' : 'bg-transparent text-zinc-400 border-white/10 hover:bg-white/5 hover:border-white/20'}\`}
                            >
                               {PRESETS[preset].name}
                            </button>
                        ))}
                     </div>
                 </div>

                 {/* Speed Slider */}
                 <div>
                     <div className="flex justify-between items-center mb-4">
                        <span className="block text-xs text-zinc-500">Draw Speed</span>
                        <span className="text-xs font-mono text-white bg-white/10 px-2 py-0.5 rounded-full">{speedMultiplier.toFixed(1)}x</span>
                     </div>
                     <input 
                       type="range" min="0.2" max="5" step="0.1" value={speedMultiplier}
                       onChange={(e) => setSpeedMultiplier(parseFloat(e.target.value))}
                       className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-white"
                     />
                 </div>
              </div>

              {/* Progress & Actions Card */}
              <div className="p-6 bg-white/[0.02] border border-white/10 rounded-3xl backdrop-blur-xl flex flex-col gap-6">
                  <div>
                      <div className="flex justify-between items-end mb-3">
                         <span className="text-xs font-mono text-zinc-400">{isDrawing ? 'Animating' : 'Ready'}</span>
                         <span className={\`text-3xl font-light tracking-tighter transition-colors font-mono \${progress === 1 ? 'text-white' : 'text-zinc-600'}\`}>
                            {Math.round(progress * 100)}%
                         </span>
                      </div>
                      <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden shadow-inner">
                         <div 
                           className="h-full bg-white transition-all duration-75 ease-out relative"
                           style={{ width: \`\${progress * 100}%\` }}
                         />
                      </div>
                  </div>

                  <div className="flex flex-col gap-3">
                     <button 
                       onClick={startAnimation} 
                       disabled={isDrawing || progress === 0}
                       className="w-full py-3.5 bg-white text-black hover:bg-zinc-200 text-sm font-semibold rounded-2xl transition-all shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2 group active:scale-95"
                     >
                       <RefreshCw className={\`w-4 h-4 \${isDrawing ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}\`} />
                       Replay Animation
                     </button>
                     <button 
                       onClick={handleDownload} 
                       disabled={isDrawing || progress < 1}
                       className="w-full py-3.5 bg-transparent border border-white/20 text-white hover:bg-white/5 text-sm font-medium rounded-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2 group active:scale-95"
                     >
                       <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                       Save Image
                     </button>
                  </div>
              </div>
          </div>
        </div>
      </main>
    </div>
  );
}
`;

fs.writeFileSync('./src/App.tsx', logic + newUI);
